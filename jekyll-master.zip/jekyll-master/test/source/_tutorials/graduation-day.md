---
title: "Graduation Day"
lesson: 6
approx_time: 10 mins
---

Congratualtions! You now know enough to start Jekylling!

Want to report a bug you found? Or give something back to the community?
Head over to the [Jekyll Repo](https://github.com/jekyll/jekyll) at GitHub
