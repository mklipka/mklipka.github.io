---
title: "YAML with Dots"
whatever: foo.bar
...

Use `{{ page.title }}` to build a full configuration for use w/Jekyll.

Whatever: {{ page.whatever }}
