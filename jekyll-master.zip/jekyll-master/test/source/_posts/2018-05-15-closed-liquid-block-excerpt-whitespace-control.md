---
title:  LIQUID_TAG_REGEX excerpt whitespace control test
layout: post
---

{%- for post in site.posts -%}
    You are in a maze of twisty little passages, all alike.
    There's lots more to say about this, but that's enough for now.
{%- endfor -%}
