---
title: Report a bug
permalink: "/docs/community/bug/"
---

If you think you've found a bug within a Jekyll plugin, open an issue in that plugin's repository &mdash; First [look for the plugin on rubygems](https://rubygems.org/) then click on the `Homepage` link to access the plugin repository.

If you think you've found a bug within Jekyll itself, [open an issue](https://github.com/jekyll/jekyll/issues/new).
